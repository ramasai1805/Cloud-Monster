<template>
    <footer class="footer py-3 bg-light footer fixed-bottom" >  
        <p class="text-center text-muted">© 2022 Company, Inc</p>
    </footer>

</template>

<script>
export default {
    setup() {
        return {};
    },
};
</script>

<style scoped>
/* .footer{
    background: url(https://www.nisum.com/hubfs/Gernal-webp/footer-bg.webp);
    background-size: 100% 111%;
    background-position: center;
    background-repeat: no-repeat;
} */

</style>
